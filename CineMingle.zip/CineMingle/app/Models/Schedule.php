<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Schedule extends Model
{
    use HasFactory;

    protected $table = 'cinema_movies_schedules';

    protected $fillable = ['movie_id', 'cinema_id', 'date', 'time', 'price'];

    public function movie()
    {
        return $this->belongsTo(Movie::class);
    }

    public function cinema()
    {
        return $this->belongsTo(Cinema::class);
    }

    public function timeslot()
    {
        return $this->belongsTo(CinemaTimeslot::class, 'cinema_timeslot_id');
    }
}
